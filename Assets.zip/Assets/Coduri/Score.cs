﻿using UnityEngine;
using UnityEngine.UI; //textul este de tip UI

public class Score : MonoBehaviour
{
    public Transform player; //pt coordonatele cubului
    public Text scoreText;

    // Update is called once per frame
    void Update()
    {
        //facem legatura intre textul scorului(de tip string) cu distanta parcaursa pe axa z(de tip float)
        //facem conversia de la float la string si punem sa afiseze fara zecimale
        scoreText.text = player.position.z.ToString("0");
    }
}
