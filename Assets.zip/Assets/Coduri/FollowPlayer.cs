﻿using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    public Transform player; //Trnasform se gaseste un Unity si reprezinta coordonatele cubului, iar prin player le vom accesa
    public Vector3 offset; //variabila de tipul Vector3 stocheaza 3 numere de tip float reprezentand axele X, Y si Z

    // Update is called once per frame
    void Update()
    {
        //folosind transform cu litera mica se refera stric la pozitia componentei a carui cod il modificam, in cazul de fata al camerei.
        transform.position = player.position + offset; //daca nu adaugam +offset camera va fi in centrul cubului
    }
}
