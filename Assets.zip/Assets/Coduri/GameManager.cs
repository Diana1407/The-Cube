﻿using UnityEngine;
using UnityEngine.SceneManagement;//biblioteca pe care o folosim pt a restarta jocul

public class GameManager : MonoBehaviour
{
    bool gameEnded = false;

    public float restartDelay = 1f;

    public GameObject completeLevelUI;

    //in functia asta afisam la completaarea nivelului mesajul de completare
    public void CompleteLevel()
    {
        completeLevelUI.SetActive(true);
    }

    public void EndGame()
    {
        if(gameEnded == false)
        {
            gameEnded = true;
            Debug.Log("GAME OVER");
            Invoke("Restart",restartDelay); //functie ce apeleaza o alta functie in cazul de fata pe ce de Restart
                                        //doar ca adauga un delay de un anumit timp pana sa apeleze functia
        }   
    }

    void Restart()
    {
        //apelam nivelul curent in cazul in care am pierdut jocul
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
