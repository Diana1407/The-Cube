﻿using UnityEngine;

public class EndTrigger : MonoBehaviour
{
    public GameManager gameManager;

    //functie predefinita ce detecteaza daca ne "lovim" de final
    //nu este la fel ca cea de ciocnire obstacole deoarece finalul este un obiect invizibil
    void OnTriggerEnter()
    {
        gameManager.CompleteLevel();
    }
}
