﻿using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    //facem legatura cu miscarea cubului 
    public PlayerMovement movement;

    //Functie predefinita ce detecteaza daca lovim ceva
    void OnCollisionEnter(Collision collisionInfo)
    {
        //daca lovim un obstacol cubul se va opri
        if(collisionInfo.collider.tag == "Obstacle")//folosind tag putem grupa mai multe obiecte de tip 
                                        ///obstacol si sa fie tratate la fel, nefiind nevoie sa setam pt fiecare
        {
            movement.enabled = false;
            FindObjectOfType<GameManager>().EndGame();//in cazul in care loveste ceva apeleaza functia de sfarsit de joc
        }
    }
}
