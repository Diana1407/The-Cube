﻿using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    //e ca si cum am declara un struct, de tipul Rigidbody pe care il chemam folosind rb
    public Rigidbody rb;

    //f-ul de la final se pune pt a recunoaste unity variabila de tip float
    public float forwardForce=2000f;  
    public float sidewaysForce=500f;
    public float upwardForce=100f;

    public bool cubeIsOnTheGround=true;//vom verifica cu el daca cubul este pe sol pt a putea lasa jucatorul sa sara o singura data

    // FixedUpdate se foloseste atunci cand faci modificari legate de "fizica" obiectului
    //Update este o functie ce se apeleaza "o data pe cadru"
    void FixedUpdate()
    {
        rb.AddForce(0,0,forwardForce * Time.deltaTime); //adauga o forta pe axa lui z prin variabila forwardForce

        //verificam comanda pe care o acceseaza jucatorul pt a ii da directie cubului
        if(Input.GetKey("d"))
        {
            //ForceMode.VelocityChnage ignora masa cubului pt a putea realiza miscarile la stanga si dreapta mai rapid
            rb.AddForce(sidewaysForce * Time.deltaTime,0,0, ForceMode.VelocityChange);
        }

        if(Input.GetKey("a"))
        {
            rb.AddForce(-sidewaysForce * Time.deltaTime,0,0, ForceMode.VelocityChange);
        }

        if(Input.GetKey("w") && cubeIsOnTheGround == true)//verificam si daca cubul este pe sol pt a putea sari
        {
            //ForceMode.Impulse tine cont de masa obiectului atunci cand aplica forta (in cazul de fata pt saritura cubului)
            rb.AddForce(0, upwardForce * Time.deltaTime,0, ForceMode.Impulse);
            cubeIsOnTheGround = false;//schimbam variabila de verificare in false deoarece in momentul acesta cubul este in aer si nu atinge solul
        }

        //Verificam daca cubul a cazut in gol, dupa care apelam functia de sfarsit de joc
        if(rb.position.y < -1f)
        {
            FindObjectOfType<GameManager>().EndGame();
        }
    }

    //functie cu care verificam daca cubul "s-a lovit cu solul" 
    //dupa care schimbam inapoi variabila de verificare daca cubul este pe sol cu adevarat
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.name == "Ground")
            {
                cubeIsOnTheGround = true;
            }
    }
}
